﻿# Pump.fun Scanner + Dashboard (Local + Cloud)

This project now supports:
- Real-time scanner loop.
- Persistent history in SQLite.
- Web dashboard.
- Cloud run in one process via `cloud_service.py`.

## Main Files

- `pumpfun_scanner.py` scanner + scoring + SQLite writes.
- `dashboard_server.py` API + dashboard server.
- `dashboard.html` UI page.
- `cloud_service.py` runs scanner thread + dashboard server (for Render/Railway).
- `render.yaml` one-click Render deploy config.
- `Procfile` process declaration for platforms that use it.

## Local Run

### 1) Run one test scan

```bash
python pumpfun_scanner.py --once
```

### 2) Run scanner loop

```bash
python pumpfun_scanner.py --interval 30 --limit 30 --workers 8
```

### 3) Start dashboard

```bash
python dashboard_server.py --host 127.0.0.1 --port 8787
```

Open: `http://127.0.0.1:8787`

## Cloud Run (recommended if Windows Defender interferes)

### A) Push to GitHub

```bash
git init
git add .
git commit -m "pumpfun scanner cloud ready"
git branch -M main
git remote add origin https://github.com/<YOUR_USER>/<YOUR_REPO>.git
git push -u origin main
```

### B) Deploy on Render

1. Go to Render dashboard.
2. New -> Blueprint.
3. Connect your GitHub repo.
4. Render will detect `render.yaml`.
5. Deploy.

After deploy, open your Render URL (dashboard is at `/`).

## Environment Variables (Cloud)

Defaults are already set in `render.yaml`:

- `RUN_SCANNER=true`
- `SCAN_INTERVAL=30`
- `SCAN_LIMIT=30`
- `SCAN_WORKERS=8`
- `SCAN_TIMEOUT=10`
- `SCAN_TOP_N=10`
- `SCAN_INCLUDE_NSFW=true`

Optional:

- `DB_PATH=scanner_data.db`
- `LATEST_JSON_PATH=latest_snapshot.json`

## Data

- SQLite database: `scanner_data.db`
  - `runs`
  - `token_snapshots`
- Latest snapshot file: `latest_snapshot.json`

## Notes

- No external Python libraries required.
- Scoring is heuristic and used for triage, not certainty.
- If the dashboard is empty, wait for the first scanner run to complete.
