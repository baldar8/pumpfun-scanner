
#!/usr/bin/env python3
from __future__ import annotations

import argparse
import concurrent.futures
import dataclasses
import datetime as dt
import json
import sqlite3
import time
import traceback
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any

FRONTEND_BASE = "https://frontend-api-v3.pump.fun"
SWAP_BASE = "https://swap-api.pump.fun"
RUGCHECK_BASE = "https://api.rugcheck.xyz"


def utc_now() -> dt.datetime:
    return dt.datetime.now(dt.timezone.utc)


def iso_utc(ts: dt.datetime) -> str:
    return ts.astimezone(dt.timezone.utc).isoformat().replace("+00:00", "Z")


def clamp(v: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, v))


def safe_float(v: Any) -> float | None:
    try:
        return None if v is None else float(v)
    except (TypeError, ValueError):
        return None


def safe_int(v: Any) -> int | None:
    try:
        return None if v is None else int(v)
    except (TypeError, ValueError):
        return None


def fetch_json(url: str, timeout: float = 10.0) -> Any | None:
    req = urllib.request.Request(url, headers={"User-Agent": "pumpfun-local-scanner/1.0", "Accept": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            raw = r.read()
        if not raw:
            return None
        return json.loads(raw.decode("utf-8"))
    except (urllib.error.HTTPError, urllib.error.URLError, TimeoutError, json.JSONDecodeError):
        return None


def fetch_new_tokens(limit: int, include_nsfw: bool, timeout: float) -> list[dict[str, Any]]:
    q = urllib.parse.urlencode({
        "limit": limit,
        "offset": 0,
        "sort": "created_timestamp",
        "order": "DESC",
        "includeNsfw": str(include_nsfw).lower(),
    })
    d = fetch_json(f"{FRONTEND_BASE}/coins/search-unrestricted?{q}", timeout=timeout)
    return [x for x in d if isinstance(x, dict)] if isinstance(d, list) else []


def fetch_market_activity(mint: str, timeout: float) -> dict[str, Any] | None:
    d = fetch_json(f"{SWAP_BASE}/v1/coins/{mint}/market-activity", timeout=timeout)
    return d if isinstance(d, dict) else None


def fetch_rug_report(mint: str, timeout: float) -> dict[str, Any] | None:
    d = fetch_json(f"{RUGCHECK_BASE}/v1/tokens/{mint}/report", timeout=timeout)
    return d if isinstance(d, dict) else None


@dataclasses.dataclass
class TokenSnapshot:
    fetched_at: str
    mint: str
    name: str
    symbol: str
    created_utc: str | None
    age_minutes: float | None
    market_cap_usd: float | None
    liquidity_usd: float | None
    holders: int | None
    buys_5m: int | None
    sells_5m: int | None
    txs_5m: int | None
    users_5m: int | None
    buyers_5m: int | None
    sellers_5m: int | None
    volume_usd_5m: float | None
    top1_nonamm_pct: float | None
    top5_nonamm_pct: float | None
    repeat_buy_ratio: float | None
    rug_score: float | None
    rug_risks_count: int | None
    creator_wallet: str | None
    creator_balance: float | None
    risk: str
    momentum: str
    momentum_score: float
    safety_score: float
    attention_score: float
    classification: str
    potential_score: float
    suspicious_score: float
    notes: str
    twitter: str | None
    website: str | None

    def to_dict(self) -> dict[str, Any]:
        return dataclasses.asdict(self)


def _created_fields(created_ms: Any) -> tuple[str | None, float | None]:
    ms = safe_int(created_ms)
    if ms is None:
        return None, None
    try:
        created = dt.datetime.fromtimestamp(ms / 1000.0, tz=dt.timezone.utc)
    except (OverflowError, OSError, ValueError):
        return None, None
    return iso_utc(created), round((utc_now() - created).total_seconds() / 60.0, 2)


def _top_holders_non_amm(rug: dict[str, Any] | None) -> tuple[float | None, float | None]:
    if not rug:
        return None, None
    known = rug.get("knownAccounts") or {}
    amm = set()
    if isinstance(known, dict):
        for owner, meta in known.items():
            if isinstance(meta, dict) and str(meta.get("type", "")).upper() == "AMM":
                amm.add(owner)
    holders = rug.get("topHolders")
    if not isinstance(holders, list):
        return None, None
    filtered = [h for h in holders if isinstance(h, dict) and h.get("owner") not in amm]
    if not filtered:
        return None, None
    top1 = safe_float(filtered[0].get("pct"))
    top5 = float(sum((safe_float(h.get("pct")) or 0.0) for h in filtered[:5]))
    return top1, top5


def evaluate_coin(coin: dict[str, Any], timeout: float) -> TokenSnapshot | None:
    mint = str(coin.get("mint") or "").strip()
    if not mint:
        return None

    act = fetch_market_activity(mint, timeout)
    rug = fetch_rug_report(mint, timeout)

    created_utc, age_min = _created_fields(coin.get("created_timestamp"))
    top1, top5 = _top_holders_non_amm(rug)

    m5 = act.get("5m", {}) if isinstance(act, dict) and isinstance(act.get("5m"), dict) else {}
    buys = safe_int(m5.get("numBuys"))
    sells = safe_int(m5.get("numSells"))
    txs = safe_int(m5.get("numTxs"))
    users = safe_int(m5.get("numUsers"))
    buyers = safe_int(m5.get("numBuyers"))
    sellers = safe_int(m5.get("numSellers"))
    volume = safe_float(m5.get("volumeUSD"))

    repeat_ratio = None
    if buys is not None and buyers is not None and buyers > 0:
        repeat_ratio = round(buys / buyers, 2)

    rug_score = safe_float((rug or {}).get("score_normalised"))
    risk_count = len(rug.get("risks") or []) if isinstance((rug or {}).get("risks"), list) else 0
    creator_wallet = (rug or {}).get("creator")
    creator_balance = safe_float((rug or {}).get("creatorBalance"))

    rs = rug_score if rug_score is not None else 50.0
    rr = repeat_ratio if repeat_ratio is not None else 1.0
    t1 = top1 if top1 is not None else 0.0

    risk = "medium"
    if rs <= 20 and risk_count <= 1:
        risk = "low"
    if rs > 50 or risk_count >= 4 or t1 >= 70:
        risk = "high"
    if rr >= 2.5 and risk == "low":
        risk = "medium"
    if rr >= 3.0 and risk == "medium":
        risk = "high"

    mom_raw = 0.0
    if buys is not None:
        mom_raw += min(40.0, buys * 1.2)
    if users is not None:
        mom_raw += min(25.0, users * 0.9)
    if volume is not None:
        mom_raw += min(35.0, volume / 120.0)
    mom_score = round(min(100.0, mom_raw), 1)
    momentum = "strong" if mom_score >= 65 else ("moderate" if mom_score >= 35 else "weak")

    bot_penalty = 15.0 if rr >= 2.2 else 0.0
    safety = round(clamp(100.0 - (rs + max(0.0, t1 - 30.0) * 0.6 + risk_count * 8.0 + bot_penalty), 0.0, 100.0), 1)
    age_for_attention = age_min if age_min is not None else 20.0
    vol_for_attention = volume if volume is not None else 0.0
    attention = round(min(100.0, mom_score * 0.7 + max(0.0, 20.0 - age_for_attention) + min(20.0, vol_for_attention / 400.0)), 1)

    potential = round(attention * 0.45 + mom_score * 0.35 + safety * 0.20, 1)
    risk_points = 40.0 if risk == "high" else (20.0 if risk == "medium" else 0.0)
    suspicious = round(risk_points + t1 * 0.6 + (rr - 1.0) * 8.0 + risk_count * 10.0, 1)

    classification = "watchlist"
    if mom_score >= 70 and safety >= 55 and risk != "high":
        classification = "hot"
    elif mom_score < 35 or safety < 35 or risk == "high":
        classification = "avoid"

    notes: list[str] = []
    if age_min is not None and age_min <= 5:
        notes.append("new<=5m")
    if buys is not None and buys >= 20:
        notes.append("fast-buys")
    if users is not None and users >= 15:
        notes.append("buyer-diversity")
    if rr >= 2.2:
        notes.append("repeat-buys/bot-like")
    if t1 > 40:
        notes.append("holder-concentration")
    if risk_count > 0:
        notes.append(f"rug-risks:{risk_count}")

    twitter = coin.get("twitter") if isinstance(coin.get("twitter"), str) else None
    website = coin.get("website") if isinstance(coin.get("website"), str) else None
    if not (twitter and twitter.strip()) and not (website and website.strip()):
        notes.append("no-social-links")

    return TokenSnapshot(
        fetched_at=iso_utc(utc_now()),
        mint=mint,
        name=str(coin.get("name") or ""),
        symbol=str(coin.get("symbol") or ""),
        created_utc=created_utc,
        age_minutes=age_min,
        market_cap_usd=safe_float(coin.get("usd_market_cap")),
        liquidity_usd=safe_float((rug or {}).get("totalMarketLiquidity")),
        holders=safe_int((rug or {}).get("totalHolders")),
        buys_5m=buys,
        sells_5m=sells,
        txs_5m=txs,
        users_5m=users,
        buyers_5m=buyers,
        sellers_5m=sellers,
        volume_usd_5m=volume,
        top1_nonamm_pct=top1,
        top5_nonamm_pct=top5,
        repeat_buy_ratio=repeat_ratio,
        rug_score=rug_score,
        rug_risks_count=risk_count,
        creator_wallet=str(creator_wallet) if creator_wallet else None,
        creator_balance=creator_balance,
        risk=risk,
        momentum=momentum,
        momentum_score=mom_score,
        safety_score=safety,
        attention_score=attention,
        classification=classification,
        potential_score=potential,
        suspicious_score=suspicious,
        notes="; ".join(notes),
        twitter=twitter,
        website=website,
    )

def top_lists(snaps: list[TokenSnapshot], n: int) -> dict[str, list[TokenSnapshot]]:
    newest = sorted(snaps, key=lambda s: s.age_minutes if s.age_minutes is not None else float("inf"))[:n]
    fastest = sorted(snaps, key=lambda s: (s.momentum_score, s.volume_usd_5m or 0.0), reverse=True)[:n]
    suspicious = sorted(snaps, key=lambda s: s.suspicious_score, reverse=True)[:n]
    potential = sorted(snaps, key=lambda s: s.potential_score, reverse=True)[:n]
    return {"newest": newest, "fastest": fastest, "suspicious": suspicious, "potential": potential}


class ScannerDB:
    def __init__(self, db_path: str) -> None:
        self.db_path = db_path

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.execute("PRAGMA journal_mode=WAL;")
        conn.execute("PRAGMA foreign_keys=ON;")
        return conn

    def init_schema(self) -> None:
        with self._connect() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS runs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    started_at TEXT NOT NULL,
                    completed_at TEXT NOT NULL,
                    token_limit INTEGER NOT NULL,
                    token_count INTEGER NOT NULL,
                    duration_seconds REAL NOT NULL
                );

                CREATE TABLE IF NOT EXISTS token_snapshots (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    run_id INTEGER NOT NULL,
                    fetched_at TEXT NOT NULL,
                    mint TEXT NOT NULL,
                    name TEXT,
                    symbol TEXT,
                    created_utc TEXT,
                    age_minutes REAL,
                    market_cap_usd REAL,
                    liquidity_usd REAL,
                    holders INTEGER,
                    buys_5m INTEGER,
                    sells_5m INTEGER,
                    txs_5m INTEGER,
                    users_5m INTEGER,
                    buyers_5m INTEGER,
                    sellers_5m INTEGER,
                    volume_usd_5m REAL,
                    top1_nonamm_pct REAL,
                    top5_nonamm_pct REAL,
                    repeat_buy_ratio REAL,
                    rug_score REAL,
                    rug_risks_count INTEGER,
                    creator_wallet TEXT,
                    creator_balance REAL,
                    risk TEXT NOT NULL,
                    momentum TEXT NOT NULL,
                    momentum_score REAL NOT NULL,
                    safety_score REAL NOT NULL,
                    attention_score REAL NOT NULL,
                    classification TEXT NOT NULL,
                    potential_score REAL NOT NULL,
                    suspicious_score REAL NOT NULL,
                    notes TEXT,
                    twitter TEXT,
                    website TEXT,
                    FOREIGN KEY (run_id) REFERENCES runs(id) ON DELETE CASCADE
                );
                CREATE INDEX IF NOT EXISTS idx_snapshots_run_id ON token_snapshots(run_id);
                CREATE INDEX IF NOT EXISTS idx_snapshots_mint_fetched ON token_snapshots(mint, fetched_at);
                """
            )

    def save_run(self, started_at: str, completed_at: str, token_limit: int, duration_seconds: float, snaps: list[TokenSnapshot]) -> int:
        with self._connect() as conn:
            cur = conn.execute(
                "INSERT INTO runs (started_at, completed_at, token_limit, token_count, duration_seconds) VALUES (?, ?, ?, ?, ?)",
                (started_at, completed_at, token_limit, len(snaps), duration_seconds),
            )
            run_id = int(cur.lastrowid)
            conn.executemany(
                """
                INSERT INTO token_snapshots (
                    run_id, fetched_at, mint, name, symbol, created_utc, age_minutes,
                    market_cap_usd, liquidity_usd, holders,
                    buys_5m, sells_5m, txs_5m, users_5m, buyers_5m, sellers_5m, volume_usd_5m,
                    top1_nonamm_pct, top5_nonamm_pct, repeat_buy_ratio,
                    rug_score, rug_risks_count, creator_wallet, creator_balance,
                    risk, momentum, momentum_score, safety_score, attention_score, classification,
                    potential_score, suspicious_score, notes, twitter, website
                )
                VALUES (
                    ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
                )
                """,
                [
                    (
                        run_id,
                        s.fetched_at,
                        s.mint,
                        s.name,
                        s.symbol,
                        s.created_utc,
                        s.age_minutes,
                        s.market_cap_usd,
                        s.liquidity_usd,
                        s.holders,
                        s.buys_5m,
                        s.sells_5m,
                        s.txs_5m,
                        s.users_5m,
                        s.buyers_5m,
                        s.sellers_5m,
                        s.volume_usd_5m,
                        s.top1_nonamm_pct,
                        s.top5_nonamm_pct,
                        s.repeat_buy_ratio,
                        s.rug_score,
                        s.rug_risks_count,
                        s.creator_wallet,
                        s.creator_balance,
                        s.risk,
                        s.momentum,
                        s.momentum_score,
                        s.safety_score,
                        s.attention_score,
                        s.classification,
                        s.potential_score,
                        s.suspicious_score,
                        s.notes,
                        s.twitter,
                        s.website,
                    )
                    for s in snaps
                ],
            )
        return run_id


def run_scan(limit: int, include_nsfw: bool, timeout: float, workers: int) -> list[TokenSnapshot]:
    newest = fetch_new_tokens(limit, include_nsfw, timeout)
    if not newest:
        return []
    snaps: list[TokenSnapshot] = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=max(1, workers)) as pool:
        futures = [pool.submit(evaluate_coin, coin, timeout) for coin in newest]
        for f in concurrent.futures.as_completed(futures):
            try:
                snap = f.result()
            except Exception:
                snap = None
            if snap is not None:
                snaps.append(snap)
    return sorted(snaps, key=lambda s: s.age_minutes if s.age_minutes is not None else float("inf"))


def write_latest_json(path: str | None, run_id: int, started: str, completed: str, snaps: list[TokenSnapshot], top_n: int) -> None:
    if not path:
        return
    payload = {
        "run_id": run_id,
        "started_at": started,
        "completed_at": completed,
        "token_count": len(snaps),
        "tokens": [s.to_dict() for s in snaps],
        "top_lists": {k: [x.to_dict() for x in v] for k, v in top_lists(snaps, top_n).items()},
    }
    Path(path).write_text(json.dumps(payload, indent=2), encoding="utf-8")


def print_summary(run_id: int, snaps: list[TokenSnapshot], top_n: int) -> None:
    hot = sum(1 for s in snaps if s.classification == "hot")
    watch = sum(1 for s in snaps if s.classification == "watchlist")
    avoid = sum(1 for s in snaps if s.classification == "avoid")
    print(f"[run {run_id}] tokens={len(snaps)} hot={hot} watchlist={watch} avoid={avoid}")
    for i, s in enumerate(top_lists(snaps, top_n)["fastest"][:3], start=1):
        print(f"  fastest#{i}: {s.name} ({s.symbol}) mom={s.momentum_score:.1f} vol5m={(s.volume_usd_5m or 0.0):.2f} class={s.classification}")


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Pump.fun scanner + history")
    p.add_argument("--db", default="scanner_data.db")
    p.add_argument("--limit", type=int, default=30)
    p.add_argument("--interval", type=float, default=30.0)
    p.add_argument("--workers", type=int, default=8)
    p.add_argument("--timeout", type=float, default=10.0)
    p.add_argument("--once", action="store_true")
    p.add_argument("--latest-json", default="latest_snapshot.json")
    p.add_argument("--top-n", type=int, default=10)
    p.add_argument("--max-runs", type=int, default=0)
    p.add_argument("--no-nsfw", action="store_true")
    return p.parse_args()


def main() -> None:
    args = parse_args()
    db = ScannerDB(args.db)
    db.init_schema()
    include_nsfw = not args.no_nsfw
    run_count = 0

    while True:
        started = utc_now()
        started_iso = iso_utc(started)
        try:
            snaps = run_scan(args.limit, include_nsfw, args.timeout, args.workers)
        except Exception:
            print("scan failed")
            traceback.print_exc()
            snaps = []

        completed = utc_now()
        completed_iso = iso_utc(completed)
        run_id = db.save_run(
            started_iso,
            completed_iso,
            args.limit,
            (completed - started).total_seconds(),
            snaps,
        )

        latest_path = args.latest_json.strip() if args.latest_json else ""
        if latest_path:
            write_latest_json(latest_path, run_id, started_iso, completed_iso, snaps, args.top_n)

        print_summary(run_id, snaps, args.top_n)
        run_count += 1

        if args.once:
            break
        if args.max_runs > 0 and run_count >= args.max_runs:
            break

        elapsed = (utc_now() - started).total_seconds()
        sleep_for = max(0.0, args.interval - elapsed)
        if sleep_for > 0:
            time.sleep(sleep_for)


if __name__ == "__main__":
    main()
