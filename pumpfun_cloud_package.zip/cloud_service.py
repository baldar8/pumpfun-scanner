﻿#!/usr/bin/env python3
from __future__ import annotations

import os
import threading
import time
from http.server import ThreadingHTTPServer

import dashboard_server
from pumpfun_scanner import ScannerDB, iso_utc, run_scan, top_lists, utc_now, write_latest_json


def env_bool(name: str, default: bool = False) -> bool:
    v = os.getenv(name)
    if v is None:
        return default
    return v.strip().lower() in {"1", "true", "yes", "on"}


def scanner_loop(
    db_path: str,
    latest_json_path: str,
    interval: float,
    limit: int,
    workers: int,
    timeout: float,
    top_n: int,
    include_nsfw: bool,
) -> None:
    db = ScannerDB(db_path)
    db.init_schema()

    while True:
        started = utc_now()
        started_iso = iso_utc(started)

        snaps = run_scan(
            limit=limit,
            include_nsfw=include_nsfw,
            timeout=timeout,
            workers=workers,
        )

        completed = utc_now()
        completed_iso = iso_utc(completed)
        run_id = db.save_run(
            started_at=started_iso,
            completed_at=completed_iso,
            token_limit=limit,
            duration_seconds=(completed - started).total_seconds(),
            snapshots=snaps,
        )

        if latest_json_path:
            write_latest_json(
                output_path=latest_json_path,
                run_id=run_id,
                started_at=started_iso,
                completed_at=completed_iso,
                snapshots=snaps,
                top_n=top_n,
            )

        fastest = top_lists(snaps, top_n).get("fastest", [])[:3]
        print(
            f"[cloud scanner] run={run_id} tokens={len(snaps)} "
            f"hot={sum(1 for s in snaps if s.classification == 'hot')}"
        )
        for i, s in enumerate(fastest, start=1):
            print(
                f"  fastest#{i}: {s.name} ({s.symbol}) "
                f"mom={s.momentum_score:.1f} vol5m={(s.volume_usd_5m or 0.0):.2f}"
            )

        elapsed = (utc_now() - started).total_seconds()
        sleep_for = max(0.0, interval - elapsed)
        if sleep_for > 0:
            time.sleep(sleep_for)


def main() -> None:
    host = os.getenv("HOST", "0.0.0.0")
    port = int(os.getenv("PORT", "8787"))

    db_path = os.getenv("DB_PATH", "scanner_data.db")
    latest_json_path = os.getenv("LATEST_JSON_PATH", "latest_snapshot.json")

    run_scanner = env_bool("RUN_SCANNER", True)
    scan_interval = float(os.getenv("SCAN_INTERVAL", "30"))
    scan_limit = int(os.getenv("SCAN_LIMIT", "30"))
    scan_workers = int(os.getenv("SCAN_WORKERS", "8"))
    scan_timeout = float(os.getenv("SCAN_TIMEOUT", "10"))
    scan_top_n = int(os.getenv("SCAN_TOP_N", "10"))
    include_nsfw = env_bool("SCAN_INCLUDE_NSFW", True)

    # Configure dashboard to read the same DB
    dashboard_server.DB_PATH = db_path

    # Ensure DB schema exists even if scanner is disabled
    ScannerDB(db_path).init_schema()

    if run_scanner:
        t = threading.Thread(
            target=scanner_loop,
            kwargs={
                "db_path": db_path,
                "latest_json_path": latest_json_path,
                "interval": scan_interval,
                "limit": scan_limit,
                "workers": scan_workers,
                "timeout": scan_timeout,
                "top_n": scan_top_n,
                "include_nsfw": include_nsfw,
            },
            daemon=True,
            name="scanner-thread",
        )
        t.start()
        print("[cloud service] scanner thread started")
    else:
        print("[cloud service] scanner disabled (RUN_SCANNER=false)")

    server = ThreadingHTTPServer((host, port), dashboard_server.Handler)
    print(f"[cloud service] dashboard on http://{host}:{port}")
    print(f"[cloud service] db={db_path}")
    server.serve_forever()


if __name__ == "__main__":
    main()
