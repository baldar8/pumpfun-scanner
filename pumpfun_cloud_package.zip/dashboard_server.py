﻿#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import sqlite3
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse


HTML_PATH = Path(__file__).with_name("dashboard.html")
DB_PATH = "scanner_data.db"


def db_conn() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def row_dicts(rows: list[sqlite3.Row]) -> list[dict]:
    return [dict(r) for r in rows]


def latest_run_id(conn: sqlite3.Connection) -> int | None:
    row = conn.execute("SELECT id FROM runs ORDER BY id DESC LIMIT 1").fetchone()
    return int(row[0]) if row else None


def get_meta() -> dict:
    with db_conn() as conn:
        run_count = conn.execute("SELECT COUNT(*) FROM runs").fetchone()[0]
        latest = conn.execute("SELECT * FROM runs ORDER BY id DESC LIMIT 1").fetchone()
        latest_data = dict(latest) if latest else None
    return {"run_count": run_count, "latest_run": latest_data}


def get_latest(limit: int) -> list[dict]:
    with db_conn() as conn:
        rid = latest_run_id(conn)
        if rid is None:
            return []
        rows = conn.execute(
            "SELECT * FROM token_snapshots WHERE run_id = ? ORDER BY age_minutes ASC LIMIT ?",
            (rid, limit),
        ).fetchall()
    return row_dicts(rows)


def get_top(kind: str, n: int) -> list[dict]:
    with db_conn() as conn:
        rid = latest_run_id(conn)
        if rid is None:
            return []
        if kind == "newest":
            order = "age_minutes ASC"
        elif kind == "fast":
            order = "momentum_score DESC, volume_usd_5m DESC"
        elif kind == "suspicious":
            order = "suspicious_score DESC"
        elif kind == "potential":
            order = "potential_score DESC"
        else:
            return []
        rows = conn.execute(
            f"SELECT * FROM token_snapshots WHERE run_id = ? ORDER BY {order} LIMIT ?",
            (rid, n),
        ).fetchall()
    return row_dicts(rows)


def get_mints(limit: int) -> list[dict]:
    with db_conn() as conn:
        rows = conn.execute(
            """
            SELECT mint, name, symbol, MAX(id) AS latest_id
            FROM token_snapshots
            GROUP BY mint
            ORDER BY latest_id DESC
            LIMIT ?
            """,
            (limit,),
        ).fetchall()
    return row_dicts(rows)


def get_history(mint: str, points: int) -> list[dict]:
    with db_conn() as conn:
        rows = conn.execute(
            """
            SELECT run_id, fetched_at, market_cap_usd, liquidity_usd, buys_5m, sells_5m,
                   volume_usd_5m, momentum_score, safety_score, attention_score,
                   potential_score, suspicious_score
            FROM token_snapshots
            WHERE mint = ?
            ORDER BY id DESC
            LIMIT ?
            """,
            (mint, points),
        ).fetchall()
    data = row_dicts(rows)
    data.reverse()
    return data


class Handler(BaseHTTPRequestHandler):
    def _json(self, payload: dict | list, status: int = 200) -> None:
        body = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _html(self, html: str, status: int = 200) -> None:
        body = html.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        path = parsed.path
        query = parse_qs(parsed.query)

        try:
            if path == "/":
                if not HTML_PATH.exists():
                    self._html("<h1>dashboard.html not found</h1>", status=500)
                    return
                self._html(HTML_PATH.read_text(encoding="utf-8"))
                return

            if path == "/api/meta":
                self._json(get_meta())
                return

            if path == "/api/latest":
                limit = int(query.get("limit", ["100"])[0])
                self._json(get_latest(limit=max(1, min(limit, 1000))))
                return

            if path in {"/api/top/newest", "/api/top/fast", "/api/top/suspicious", "/api/top/potential"}:
                kind = path.split("/")[-1]
                n = int(query.get("n", ["10"])[0])
                self._json(get_top(kind, n=max(1, min(n, 100))))
                return

            if path == "/api/mints":
                limit = int(query.get("limit", ["500"])[0])
                self._json(get_mints(limit=max(1, min(limit, 5000))))
                return

            if path == "/api/history":
                mint = (query.get("mint", [""])[0] or "").strip()
                points = int(query.get("points", ["200"])[0])
                if not mint:
                    self._json({"error": "mint is required"}, status=400)
                    return
                self._json(get_history(mint, points=max(1, min(points, 5000))))
                return

            self._json({"error": "not found"}, status=404)
        except Exception as exc:
            self._json({"error": "server error", "detail": str(exc)}, status=500)

    def log_message(self, fmt: str, *args) -> None:
        print(f"[dashboard] {self.address_string()} - {fmt % args}")


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Local pump.fun dashboard server")
    p.add_argument("--db", default="scanner_data.db", help="SQLite database path")
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--port", type=int, default=8787)
    return p.parse_args()


def main() -> None:
    global DB_PATH
    args = parse_args()
    DB_PATH = args.db
    server = ThreadingHTTPServer((args.host, args.port), Handler)
    print(f"Dashboard running at http://{args.host}:{args.port}")
    print(f"Using DB: {DB_PATH}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping dashboard server...")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
